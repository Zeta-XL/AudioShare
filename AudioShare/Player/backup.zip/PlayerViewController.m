
//
//  PlayerViewController.m
//  AudioShare
//
//  Created by lanou3g on 15/7/28.
//  Copyright (c) 2015年 DLZ. All rights reserved.
//

#import "PlayerViewController.h"
#import "TracksListTableViewController.h"

static PlayerViewController *singlePlayer = nil;

@interface PlayerViewController ()

// UI布局

@property (weak, nonatomic) IBOutlet UIButton *backButton; // 返回
@property (weak, nonatomic) IBOutlet UIButton *autoShutdown; // 定时关闭

@property (weak, nonatomic) IBOutlet UISlider *timeGoingSlider; // 播放进度条
@property (weak, nonatomic) IBOutlet UIButton *playButton; // 播放/暂停按键
@property (weak, nonatomic) IBOutlet UIButton *preButton;  // 上一首
@property (weak, nonatomic) IBOutlet UIButton *nextButton; // 下一首
@property (weak, nonatomic) IBOutlet UIButton *historyButton; // 播放历史
@property (weak, nonatomic) IBOutlet UIButton *listButton;  // 播放列表

// 记录走后的Item
@property (nonatomic, strong)SpecialItem *lastItem;

// 记录当前的item
@property (nonatomic, strong)SpecialItem *currentItem;

// 上一次直播的URL
@property (nonatomic, copy)NSString *lastUrlString;

@end

@implementation PlayerViewController
// 单例初始化
+ (instancetype)sharedPlayer
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singlePlayer = [[PlayerViewController alloc] init];
    });
    
    return singlePlayer;
}

#pragma mark ---- 视图生命周期
// 视图将要出现
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    if (_urlString) {
        self.currentItem = [self createPlayerItemWithURLString:_urlString];
        // 初始化播放器
        [self p_iniWithItem: _currentItem];
    } else {
        if (_lastUrlString) {
            self.currentItem = [self createPlayerItemWithURLString:_lastUrlString];
            self.urlString = _lastUrlString;
        } else {
            self.currentItem = _lastItem;
        }
        
    }
    if (_currentItem.isLiveCast) {
        self.preButton.enabled = NO;
        self.nextButton.enabled = NO;
        self.listButton.enabled = NO;
        
        
    } else {
        self.preButton.enabled = YES;
        self.nextButton.enabled = YES;
        self.listButton.enabled = YES;
        // 处理数据
        [self p_data];
    }
    
    
    
    
}

// 视图出现
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    
    if (_isPlaying == NO) {
        [self playAction:_playButton];
    } else {
        [_player play];
    }
    
}

// 视图将要消失
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    
    self.lastItem = _currentItem;
    if (_lastItem.isLiveCast == YES) {
        self.lastUrlString = _urlString;
    } else {
        self.lastUrlString = nil;
    }
    self.currentItem = nil;
    self.urlString = nil;
}

//-------------- 初始化数据  -----------//
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _currentIndex = 0;
    if (_urlString == nil) {
        self.lastItem = [self createPlayerItemWithURLString:kStreamUrl1];
        [self p_iniWithItem: _lastItem];
    }
    
    
}


#pragma mark ---- 处理数据

/***********
处理在线听书, 相关数据
************/
- (void)p_data
{
    if (_currentIndex == 0) {
        self.preButton.enabled = NO;
    } else if (_currentIndex == _tracksList.count - 1) {
        self.nextButton.enabled = YES;
    }
    
    
    self.tracksList = [NSMutableArray array];
    [_tracksList addObject:_currentItem];
    NSString *local = [[NSBundle mainBundle] pathForResource:@"testDemo.aac" ofType:nil];
    for (NSString *urlStr in @[ kStreamUrl2, kStreamUrl3, local]) {
        SpecialItem *item= [self createPlayerItemWithURLString:urlStr];
        [_tracksList addObject:item];
    }
    
}




#pragma mark ---- 播放器相关
// 根据UrlString初始化播放项目
- (SpecialItem *)createPlayerItemWithURLString:(NSString *)urlString
{
    NSURL *url = nil;
    // 准备播放对象
    SpecialItem *playerItem = nil;
    if ([urlString hasSuffix:@".m3u8"]) {
        url = [NSURL URLWithString:urlString];
        playerItem = [[SpecialItem alloc] initWithURL:url];
        playerItem.isLiveCast = YES;

    } else {
        if ([urlString hasSuffix:@".aac"]) {
            url = [NSURL fileURLWithPath:urlString];
        } else {
            url = [NSURL URLWithString:urlString];
        }
        playerItem = [[SpecialItem alloc] initWithURL:url];
        playerItem.isLiveCast = NO;
    }
    return playerItem;
    
}


// 根据列表索引准备播放器///// 暂未使用  //////
- (void)p_initWithIndex:(NSInteger)index
{
    AVPlayerItem *avItem = _tracksList[_currentIndex];
    self.player = [AVPlayer playerWithPlayerItem:avItem];
    
}

// 根据item出事化播放器
- (void)p_iniWithItem:(SpecialItem *)playerItem;
{
    self.player = [AVPlayer playerWithPlayerItem:playerItem];
}


#pragma mark --- button响应事件
// 返回
- (IBAction)backAction:(UIButton *)sender
{
    [self dismissViewControllerAnimated:YES completion:^{
        DLog(@"退出播放器");
    }];
}

// 定时关闭(暂停)
- (IBAction)autoShutdownAction:(UIButton *)sender
{
    
    DLog(@"定时关闭");
}

// slider进度条
- (IBAction)timeSliderAction:(UISlider *)sender
{
    
}

// 播放按键
- (IBAction)playAction:(UIButton *)sender
{
    _isPlaying = !_isPlaying;
    if (_isPlaying) {
        [sender setImage:[UIImage imageNamed:@"pause_btn.jpg"] forState:(UIControlStateNormal)];
        // 判断当前的item属性
        if (self.currentItem.isLiveCast) { // 直播
            self.currentItem = [self createPlayerItemWithURLString:_urlString];
            [self p_iniWithItem:_currentItem];
        }
        [self.player play];
        
    } else {
        [sender setImage:[UIImage imageNamed:@"play_btn.jpg"] forState:(UIControlStateNormal)];
        
        [self.player pause];
    }
    
}

// 上一首
- (IBAction)preButtonAction:(UIButton *)sender
{
    if (self.nextButton.enabled == NO) {
        self.nextButton.enabled = YES;
    }
    if (_currentIndex > 0) {
        _currentIndex--;
        if (_currentIndex == 0) {
            sender.enabled = NO;
        }
        [self.player replaceCurrentItemWithPlayerItem:_tracksList[_currentIndex]];
    }
   
}


// 下一首
- (IBAction)nextButtonAction:(UIButton *)sender
{
    if (self.preButton.enabled == NO) {
        self.preButton.enabled = YES;
    }
    if (_currentIndex < _tracksList.count - 1) {
        _currentIndex++;
        if (_currentIndex == _tracksList.count - 1) {
            sender.enabled = NO;
        }
        [self.player replaceCurrentItemWithPlayerItem:_tracksList[_currentIndex]];
    }
}

// 播放列表
- (IBAction)ListButtonAction:(UIButton *)sender
{
    TracksListTableViewController *trackListVC = [[TracksListTableViewController alloc] init];
    [self presentViewController:trackListVC animated:YES completion:^{
        DLog(@"打开列表");
    }];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}






@end
